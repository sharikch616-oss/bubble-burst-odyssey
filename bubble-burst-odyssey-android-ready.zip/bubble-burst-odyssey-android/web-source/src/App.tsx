/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import { HeaderHUD } from './components/HeaderHUD';
import { PowerUpTray } from './components/PowerUpTray';
import { GameCanvas } from './components/GameCanvas';
import { LevelSelectModal } from './components/LevelSelectModal';
import { VictoryModal } from './components/VictoryModal';
import { GameOverModal } from './components/GameOverModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { LEVELS } from './game/levels';
import { BubbleColor, LevelConfig, PowerUpType, UserProgress } from './game/types';
import { loadProgress, recordLevelResult, saveProgress } from './game/storage';
import { sound } from './game/audio';

export default function App() {
  const [progress, setProgress] = useState<UserProgress>(loadProgress);
  const [currentLevelId, setCurrentLevelId] = useState<number>(1);
  const [score, setScore] = useState<number>(0);
  const [movesRemaining, setMovesRemaining] = useState<number>(28);
  const [currentCombo, setCurrentCombo] = useState<number>(1);
  const [starsEarned, setStarsEarned] = useState<number>(0);

  const [currentBubble, setCurrentBubble] = useState<BubbleColor>('green');
  const [nextBubble, setNextBubble] = useState<BubbleColor>('yellow');
  const [activePowerUp, setActivePowerUp] = useState<PowerUpType | null>(null);

  const [activeModal, setActiveModal] = useState<
    'none' | 'level_select' | 'help' | 'victory' | 'game_over'
  >('none');
  const [gameOverReason, setGameOverReason] = useState<'out_of_bubbles' | 'ceiling_breach'>(
    'out_of_bubbles'
  );

  const level: LevelConfig =
    LEVELS.find((l) => l.id === currentLevelId) || LEVELS[0];

  // Initialize bubbles for a level
  const initLevelBubbles = useCallback((lvl: LevelConfig) => {
    const colors = lvl.allowedColors;
    const c1 = colors[Math.floor(Math.random() * colors.length)];
    const c2 = colors[Math.floor(Math.random() * colors.length)];
    setCurrentBubble(c1);
    setNextBubble(c2);
    setActivePowerUp(null);
    setScore(0);
    setMovesRemaining(lvl.bubbleLimit);
    setStarsEarned(0);
    setCurrentCombo(1);
  }, []);

  // Sync sound settings with audio engine
  useEffect(() => {
    sound.setMuted(!progress.soundEnabled);
  }, [progress.soundEnabled]);

  // Load level on start
  useEffect(() => {
    initLevelBubbles(level);
  }, [level, initLevelBubbles]);

  // Recalculate stars as score increments
  useEffect(() => {
    const [t1, t2, t3] = level.starThresholds;
    if (score >= t3) {
      setStarsEarned(3);
    } else if (score >= t2) {
      setStarsEarned(2);
    } else if (score >= t1) {
      setStarsEarned(1);
    } else {
      setStarsEarned(0);
    }
  }, [score, level.starThresholds]);

  // Swap bubble handler
  const handleSwapBubbles = useCallback(() => {
    if (activeModal !== 'none') return;
    sound.playSwap();
    setCurrentBubble(nextBubble);
    setNextBubble(currentBubble);
  }, [nextBubble, currentBubble, activeModal]);

  // Power-up selection
  const handleSelectPowerUp = useCallback(
    (type: PowerUpType) => {
      if (activeModal !== 'none') return;
      const count = progress.powerUpInventory[type] || 0;
      if (count <= 0 && activePowerUp !== type) return;

      if (activePowerUp === type) {
        // Deselect
        setActivePowerUp(null);
      } else {
        sound.playPowerUpSelect();
        setActivePowerUp(type);
      }
    },
    [progress.powerUpInventory, activePowerUp, activeModal]
  );

  // Consume power-up after firing
  const handleConsumePowerUp = useCallback(() => {
    if (!activePowerUp) return;
    const updated = {
      ...progress,
      powerUpInventory: {
        ...progress.powerUpInventory,
        [activePowerUp]: Math.max(0, (progress.powerUpInventory[activePowerUp] || 0) - 1),
      },
    };
    setProgress(updated);
    saveProgress(updated);
    setActivePowerUp(null);
  }, [activePowerUp, progress]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeModal !== 'none') {
        if (e.key === 'Escape') setActiveModal('none');
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleSwapBubbles();
      } else if (e.key === '1') {
        handleSelectPowerUp('bomb');
      } else if (e.key === '2') {
        handleSelectPowerUp('fireball');
      } else if (e.key === '3') {
        handleSelectPowerUp('rainbow');
      } else if (e.key === '4') {
        handleSelectPowerUp('lightning');
      } else if (e.key === 'Escape') {
        if (activePowerUp) {
          setActivePowerUp(null);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeModal, handleSwapBubbles, handleSelectPowerUp, activePowerUp]);

  // Audio mute toggle
  const handleToggleSound = () => {
    const updated = { ...progress, soundEnabled: !progress.soundEnabled };
    setProgress(updated);
    saveProgress(updated);
  };

  // Restart current level
  const handleRestartLevel = () => {
    setActiveModal('none');
    initLevelBubbles(level);
  };

  // Victory callback
  const handleVictory = (finalScore: number) => {
    // Determine stars
    let stars = 1;
    if (finalScore >= level.starThresholds[2]) stars = 3;
    else if (finalScore >= level.starThresholds[1]) stars = 2;

    const updated = recordLevelResult(level.id, finalScore, stars);
    setProgress(updated);
    setActiveModal('victory');
  };

  // Game over callback
  const handleGameOver = (reason: 'out_of_bubbles' | 'ceiling_breach') => {
    setGameOverReason(reason);
    setActiveModal('game_over');
  };

  // Go to next level
  const handleNextLevel = () => {
    const nextId = Math.min(12, level.id + 1);
    setCurrentLevelId(nextId);
    setActiveModal('none');
  };

  // Select specific level from stage modal
  const handleSelectLevel = (lvlId: number) => {
    setCurrentLevelId(lvlId);
    setActiveModal('none');
  };

  // Advance bubble queue
  const handleAdvanceBubble = (newCurrent: BubbleColor, newNext: BubbleColor) => {
    setCurrentBubble(newCurrent);
    setNextBubble(newNext);
  };

  const highScore = progress.levelHighScores[level.id] || 0;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100 select-none">
      {/* Top HUD */}
      <HeaderHUD
        currentLevel={level}
        score={score}
        highScore={highScore}
        movesRemaining={movesRemaining}
        starsEarned={starsEarned}
        soundEnabled={progress.soundEnabled}
        onToggleSound={handleToggleSound}
        onRestart={handleRestartLevel}
        onOpenLevelSelect={() => setActiveModal('level_select')}
        onOpenHelp={() => setActiveModal('help')}
      />

      {/* Main Interactive Stage Area */}
      <main className="flex-1 flex flex-col items-center justify-center overflow-hidden relative p-1">
        <GameCanvas
          key={`canvas_lvl_${level.id}_${movesRemaining === level.bubbleLimit ? 'fresh' : 'active'}`}
          level={level}
          aimGuideEnabled={progress.aimGuideEnabled}
          activePowerUp={activePowerUp}
          currentBubble={currentBubble}
          nextBubble={nextBubble}
          onScoreUpdate={setScore}
          onMovesUpdate={setMovesRemaining}
          onCombosUpdate={setCurrentCombo}
          onVictory={handleVictory}
          onGameOver={handleGameOver}
          onAdvanceBubble={handleAdvanceBubble}
          onConsumePowerUp={handleConsumePowerUp}
        />
      </main>

      {/* Bottom Power-Ups & Swap Controls */}
      <footer className="w-full">
        <PowerUpTray
          currentBubble={currentBubble}
          nextBubble={nextBubble}
          activePowerUp={activePowerUp}
          inventory={progress.powerUpInventory}
          onSelectPowerUp={handleSelectPowerUp}
          onSwapBubbles={handleSwapBubbles}
        />
      </footer>

      {/* Modals & Overlays */}
      {activeModal === 'level_select' && (
        <LevelSelectModal
          levels={LEVELS}
          currentLevelId={level.id}
          progress={progress}
          onSelectLevel={handleSelectLevel}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'help' && (
        <HowToPlayModal onClose={() => setActiveModal('none')} />
      )}

      {activeModal === 'victory' && (
        <VictoryModal
          level={level}
          score={score}
          bubblesLeft={movesRemaining}
          stars={starsEarned}
          highScore={highScore}
          onNextLevel={handleNextLevel}
          onReplay={handleRestartLevel}
          onLevelSelect={() => setActiveModal('level_select')}
        />
      )}

      {activeModal === 'game_over' && (
        <GameOverModal
          level={level}
          score={score}
          reason={gameOverReason}
          onRetry={handleRestartLevel}
          onLevelSelect={() => setActiveModal('level_select')}
        />
      )}
    </div>
  );
}
