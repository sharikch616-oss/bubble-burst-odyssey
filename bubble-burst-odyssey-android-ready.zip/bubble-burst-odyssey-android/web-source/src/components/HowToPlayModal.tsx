/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Target, ArrowLeftRight, Sparkles, ShieldAlert, Award } from 'lucide-react';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-5 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-sky-400" />
            <h2 className="text-xl font-black text-white tracking-wide">HOW TO PLAY</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="space-y-4 my-4 overflow-y-auto pr-1 text-xs text-slate-300">
          {/* Rule 1 */}
          <div className="flex gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
            <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400 shrink-0 self-start">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">Aim & Match 3</h3>
              <p className="text-slate-400 leading-relaxed">
                Move your cursor or finger to aim the laser sight. Click or release to launch.
                Connect 3 or more bubbles of the same color to pop them.
              </p>
            </div>
          </div>

          {/* Rule 2 */}
          <div className="flex gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 self-start">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">Bank Shots & Cluster Drops</h3>
              <p className="text-slate-400 leading-relaxed">
                Bounce shots off the left and right walls to slip into hard-to-reach pockets.
                When you pop bubbles that anchor a floating cluster, all disconnected bubbles
                fall into the bottom score buckets for up to <strong>+500 points</strong> each!
              </p>
            </div>
          </div>

          {/* Rule 3 */}
          <div className="flex gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400 shrink-0 self-start">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">Bubble Swapping</h3>
              <p className="text-slate-400 leading-relaxed">
                Need a different color? Press the <strong>SPACEBAR</strong> or tap the swap button
                to instantly switch between your current bubble and the next bubble in the queue.
              </p>
            </div>
          </div>

          {/* Rule 4 */}
          <div className="flex gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 shrink-0 self-start">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white mb-1">Ceiling Drops & Danger Line</h3>
              <p className="text-slate-400 leading-relaxed">
                Missing a match counts as a foul. After consecutive fouls, the ceiling lowers!
                If bubbles cross below the red dashed <strong>Danger Threshold</strong>, it is game over.
              </p>
            </div>
          </div>

          {/* Power-ups breakdown */}
          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
            <h3 className="font-bold text-sm text-white mb-2">Special Power-Ups & Bubbles</h3>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-center gap-2">
                <span className="text-base">💣</span>
                <div>
                  <span className="font-bold text-white">[1] Bomb:</span>
                  <div className="text-slate-400">Blasts 2-ring radius</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-base">🔥</span>
                <div>
                  <span className="font-bold text-white">[2] Fireball:</span>
                  <div className="text-slate-400">Pierces path through</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-base">🌈</span>
                <div>
                  <span className="font-bold text-white">[3] Rainbow:</span>
                  <div className="text-slate-400">Matches any color</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-base">⚡</span>
                <div>
                  <span className="font-bold text-white">[4] Lightning:</span>
                  <div className="text-slate-400">Clears entire row</div>
                </div>
              </div>
              <div className="flex items-center gap-2 col-span-2 pt-1 border-t border-slate-700/40">
                <span className="text-base">🧱</span>
                <div>
                  <span className="font-bold text-white">Stone Obstacle:</span>
                  <span className="text-slate-400 ml-1">
                    Cannot be popped by matching! Drop by detaching its anchors.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <button
          onClick={onClose}
          className="w-full py-2.5 bg-sky-500 hover:bg-sky-400 text-white font-bold rounded-xl transition-all cursor-pointer text-xs"
        >
          GOT IT, LET'S PLAY!
        </button>
      </div>
    </div>
  );
};
