/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  Grid,
  HelpCircle,
  Star,
  Sparkles,
} from 'lucide-react';
import { LevelConfig } from '../game/types';

interface HeaderHUDProps {
  currentLevel: LevelConfig;
  score: number;
  highScore: number;
  movesRemaining: number;
  starsEarned: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onRestart: () => void;
  onOpenLevelSelect: () => void;
  onOpenHelp: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  currentLevel,
  score,
  highScore,
  movesRemaining,
  starsEarned,
  soundEnabled,
  onToggleSound,
  onRestart,
  onOpenLevelSelect,
  onOpenHelp,
}) => {
  // Calculate progress toward 3 stars
  const maxThreshold = currentLevel.starThresholds[2];
  const starProgress = Math.min(100, Math.round((score / maxThreshold) * 100));

  return (
    <header className="w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white px-4 py-2.5 flex flex-col gap-2 select-none shadow-md">
      {/* Top Row: Brand & Level Info + System Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="font-black text-lg tracking-wider bg-gradient-to-r from-sky-400 via-teal-300 to-indigo-400 bg-clip-text text-transparent">
              PRISM BURST
            </span>
            <span className="text-xs text-slate-400 hidden sm:inline">· Level {currentLevel.id}</span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
            <span className="font-semibold text-sky-300">{currentLevel.name}</span>
            <span className="text-slate-500">·</span>
            <span
              className={
                currentLevel.difficulty === 'Easy'
                  ? 'text-emerald-400'
                  : currentLevel.difficulty === 'Medium'
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }
            >
              {currentLevel.difficulty}
            </span>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1">
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
          </button>

          <button
            onClick={onRestart}
            title="Restart Level"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenLevelSelect}
            title="Select Level"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            <Grid className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenHelp}
            title="How to Play"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Bottom Row: Score, Star Bar, and Shots Remaining */}
      <div className="flex items-center justify-between gap-3 pt-1 border-t border-slate-800/60">
        {/* Score & Best */}
        <div className="flex items-baseline gap-2">
          <div className="text-xl font-black tabular-nums tracking-tight text-white">
            {score.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 font-medium hidden xs:inline">
            BEST: <span className="text-slate-300 tabular-nums">{highScore.toLocaleString()}</span>
          </div>
        </div>

        {/* Star Progress Bar */}
        <div className="flex-1 max-w-xs mx-2 flex flex-col gap-1">
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
            <span>STARS</span>
            <div className="flex items-center gap-1">
              {[1, 2, 3].map((starNum) => (
                <Star
                  key={starNum}
                  className={`w-3.5 h-3.5 ${
                    starsEarned >= starNum
                      ? 'fill-amber-400 text-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.6)]'
                      : 'text-slate-600'
                  }`}
                />
              ))}
            </div>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden border border-slate-700/60 relative">
            <div
              className="bg-gradient-to-r from-amber-500 to-yellow-300 h-full transition-all duration-300 ease-out"
              style={{ width: `${starProgress}%` }}
            />
          </div>
        </div>

        {/* Shots Remaining Counter */}
        <div className="flex items-center gap-1.5 bg-slate-800/90 px-2.5 py-1 rounded-md border border-slate-700">
          <Sparkles className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-xs text-slate-400 font-medium">BUBBLES:</span>
          <span
            className={`font-black text-sm tabular-nums ${
              movesRemaining <= 4 ? 'text-rose-400 animate-pulse' : 'text-sky-300'
            }`}
          >
            {movesRemaining}
          </span>
        </div>
      </div>
    </header>
  );
};
