/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RotateCcw, Grid, AlertTriangle } from 'lucide-react';
import { LevelConfig } from '../game/types';

interface GameOverModalProps {
  level: LevelConfig;
  score: number;
  reason: 'out_of_bubbles' | 'ceiling_breach';
  onRetry: () => void;
  onLevelSelect: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  level,
  score,
  reason,
  onRetry,
  onLevelSelect,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-center flex flex-col items-center">
        {/* Warning Icon */}
        <div className="w-16 h-16 rounded-full bg-rose-500/15 border border-rose-500/30 flex items-center justify-center mb-3">
          <AlertTriangle className="w-8 h-8 text-rose-400 drop-shadow-[0_0_10px_rgba(244,63,94,0.6)]" />
        </div>

        <h2 className="text-2xl font-black text-white tracking-wide">GAME OVER</h2>
        <p className="text-xs text-rose-300 font-medium mt-1">
          {reason === 'out_of_bubbles'
            ? 'No more bubbles left in the launcher!'
            : 'Bubbles crossed the danger threshold!'}
        </p>

        {/* Level & Score Summary */}
        <div className="w-full bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 my-4 space-y-2 text-xs">
          <div className="flex justify-between items-center text-slate-300">
            <span>Level {level.id}:</span>
            <span className="font-semibold text-white">{level.name}</span>
          </div>
          <div className="flex justify-between items-center text-slate-300 pt-1 border-t border-slate-700/50">
            <span>Score Reached:</span>
            <span className="text-base font-bold text-amber-300 tabular-nums">
              {score.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Strategy Tip */}
        <div className="w-full text-left bg-slate-800/40 border border-slate-700/40 rounded-lg p-2.5 mb-5 text-[11px] text-slate-400">
          <span className="font-bold text-sky-400">Tactical Tip:</span>{' '}
          {reason === 'out_of_bubbles'
            ? 'Aim for the highest connected anchors! Severing a single root bubble drops every bubble hanging below it.'
            : 'Use bank shots off the side walls to pierce hidden color clusters, and trigger Bombs or Lightnings before the ceiling drops.'}
        </div>

        {/* Action Buttons */}
        <div className="w-full flex gap-2">
          <button
            onClick={onRetry}
            className="flex-1 py-3 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 active:scale-98 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer text-xs"
          >
            <RotateCcw className="w-4 h-4" />
            <span>TRY AGAIN</span>
          </button>

          <button
            onClick={onLevelSelect}
            className="py-3 px-4 bg-slate-800 hover:bg-slate-700 active:scale-98 text-slate-200 font-semibold rounded-xl border border-slate-700 flex items-center justify-center gap-1.5 transition-all cursor-pointer text-xs"
          >
            <Grid className="w-4 h-4" />
            <span>Levels</span>
          </button>
        </div>
      </div>
    </div>
  );
};
