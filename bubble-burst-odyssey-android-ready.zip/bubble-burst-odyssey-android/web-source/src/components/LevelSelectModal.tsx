/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Lock, Star, Play } from 'lucide-react';
import { LevelConfig, UserProgress } from '../game/types';

interface LevelSelectModalProps {
  levels: LevelConfig[];
  currentLevelId: number;
  progress: UserProgress;
  onSelectLevel: (levelId: number) => void;
  onClose: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  levels,
  currentLevelId,
  progress,
  onSelectLevel,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-5 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-black text-white tracking-wide">STAGE SELECT</h2>
            <p className="text-xs text-slate-400">Choose a sector to clear</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Level Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-4 overflow-y-auto pr-1">
          {levels.map((lvl) => {
            const isUnlocked = lvl.id <= progress.unlockedLevel;
            const isCurrent = lvl.id === currentLevelId;
            const stars = progress.levelStars[lvl.id] || 0;
            const highScore = progress.levelHighScores[lvl.id] || 0;

            return (
              <button
                key={lvl.id}
                disabled={!isUnlocked}
                onClick={() => {
                  if (isUnlocked) {
                    onSelectLevel(lvl.id);
                    onClose();
                  }
                }}
                className={`relative flex flex-col p-3 rounded-xl border text-left transition-all ${
                  isCurrent
                    ? 'bg-slate-800/90 border-sky-400 shadow-[0_0_12px_rgba(56,189,248,0.3)] ring-1 ring-sky-400'
                    : isUnlocked
                    ? 'bg-slate-800/60 hover:bg-slate-800 border-slate-700 hover:border-slate-500 cursor-pointer'
                    : 'bg-slate-950/40 border-slate-850 opacity-45 cursor-not-allowed'
                }`}
              >
                {/* Level Number & Difficulty Tag */}
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-black text-sm text-white">
                    LVL {lvl.id}
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                      lvl.difficulty === 'Easy'
                        ? 'text-emerald-400 bg-emerald-950/60'
                        : lvl.difficulty === 'Medium'
                        ? 'text-amber-400 bg-amber-950/60'
                        : 'text-rose-400 bg-rose-950/60'
                    }`}
                  >
                    {lvl.difficulty}
                  </span>
                </div>

                {/* Level Title */}
                <div className="text-xs font-bold text-slate-200 truncate mb-1">
                  {lvl.name}
                </div>

                {/* Stars and Status */}
                <div className="flex items-center justify-between mt-auto pt-2 border-t border-slate-700/40">
                  {isUnlocked ? (
                    <>
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3].map((s) => (
                          <Star
                            key={s}
                            className={`w-3.5 h-3.5 ${
                              stars >= s
                                ? 'fill-amber-400 text-amber-400'
                                : 'text-slate-700'
                            }`}
                          />
                        ))}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400">
                        {highScore > 0 ? highScore.toLocaleString() : '—'}
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center gap-1 text-[11px] text-slate-500">
                      <Lock className="w-3.5 h-3.5" />
                      <span>Locked</span>
                    </div>
                  )}
                </div>

                {/* Play hover pill indicator */}
                {isUnlocked && (
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-3.5 h-3.5 text-sky-400 fill-sky-400" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex justify-between items-center">
          <span>Earn 3 stars to unlock bonus power-ups!</span>
          <span className="font-semibold text-sky-400">
            {Object.values(progress.levelStars).filter((s) => s === 3).length} / 12 Perfect
          </span>
        </div>
      </div>
    </div>
  );
};
