/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Star, Trophy, ArrowRight, RotateCcw, Grid } from 'lucide-react';
import { LevelConfig } from '../game/types';

interface VictoryModalProps {
  level: LevelConfig;
  score: number;
  bubblesLeft: number;
  stars: number;
  highScore: number;
  onNextLevel: () => void;
  onReplay: () => void;
  onLevelSelect: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  level,
  score,
  bubblesLeft,
  stars,
  highScore,
  onNextLevel,
  onReplay,
  onLevelSelect,
}) => {
  useEffect(() => {
    // Launch celebratory confetti bursts
    const count = 200;
    const defaults = {
      origin: { y: 0.6 },
      zIndex: 9999,
    };

    function fire(particleRatio: number, opts: confetti.Options) {
      confetti({
        ...defaults,
        ...opts,
        particleCount: Math.floor(count * particleRatio),
      });
    }

    fire(0.25, {
      spread: 26,
      startVelocity: 55,
      colors: ['#38bdf8', '#34d399', '#fbbf24', '#f43f5e'],
    });
    fire(0.2, {
      spread: 60,
      colors: ['#a855f7', '#ec4899', '#f97316'],
    });
    fire(0.35, {
      spread: 100,
      decay: 0.91,
      scalar: 0.8,
    });
    fire(0.1, {
      spread: 120,
      startVelocity: 25,
      decay: 0.92,
      scalar: 1.2,
    });
  }, []);

  const bubbleBonus = bubblesLeft * 200;
  const isNewHighScore = score >= highScore;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-center flex flex-col items-center">
        {/* Victory Header */}
        <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mb-3">
          <Trophy className="w-8 h-8 text-amber-400 drop-shadow-[0_0_12px_rgba(251,191,36,0.6)]" />
        </div>

        <h2 className="text-2xl font-black text-white tracking-wide">LEVEL CLEARED!</h2>
        <p className="text-xs text-sky-300 font-medium mt-0.5">
          Level {level.id}: {level.name}
        </p>

        {/* 3 Stars Trophy Display */}
        <div className="flex items-center justify-center gap-3 my-5">
          {[1, 2, 3].map((starIdx) => {
            const isEarned = stars >= starIdx;
            return (
              <div
                key={starIdx}
                className={`transition-all duration-500 transform ${
                  isEarned ? 'scale-110' : 'scale-90 opacity-40'
                }`}
              >
                <Star
                  className={`w-9 h-9 ${
                    isEarned
                      ? 'fill-amber-400 text-amber-400 drop-shadow-[0_0_12px_rgba(251,191,36,0.8)]'
                      : 'text-slate-700'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Score & Statistics Breakdown */}
        <div className="w-full bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 mb-5 space-y-2 text-xs">
          <div className="flex justify-between items-center text-slate-300">
            <span>Bubbles Remaining:</span>
            <span className="font-semibold text-white">
              {bubblesLeft} <span className="text-emerald-400">(+{bubbleBonus.toLocaleString()} pts)</span>
            </span>
          </div>
          <div className="flex justify-between items-center text-slate-300 pt-1 border-t border-slate-700/50">
            <span className="text-sm font-bold text-white">Final Score:</span>
            <span className="text-lg font-black text-amber-300 tabular-nums">
              {score.toLocaleString()}
            </span>
          </div>

          {isNewHighScore && (
            <div className="text-[11px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 py-1 rounded">
              ★ NEW HIGH SCORE! ★
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          {level.id < 12 ? (
            <button
              onClick={onNextLevel}
              className="w-full py-3 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 active:scale-98 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>NEXT LEVEL</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <div className="text-sm font-bold text-amber-300 py-2">
              🎉 Congratulations! You have conquered all levels!
            </div>
          )}

          <div className="flex gap-2 w-full">
            <button
              onClick={onReplay}
              className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-98 text-slate-200 font-semibold rounded-xl border border-slate-700 flex items-center justify-center gap-1.5 transition-all cursor-pointer text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Replay</span>
            </button>

            <button
              onClick={onLevelSelect}
              className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-98 text-slate-200 font-semibold rounded-xl border border-slate-700 flex items-center justify-center gap-1.5 transition-all cursor-pointer text-xs"
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Levels</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
