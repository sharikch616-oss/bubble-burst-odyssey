/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeftRight } from 'lucide-react';
import { BubbleColor, PowerUpType } from '../game/types';
import { BUBBLE_STYLES } from '../game/constants';

interface PowerUpTrayProps {
  currentBubble: BubbleColor;
  nextBubble: BubbleColor;
  activePowerUp: PowerUpType | null;
  inventory: Record<PowerUpType, number>;
  onSelectPowerUp: (type: PowerUpType) => void;
  onSwapBubbles: () => void;
}

const POWER_UPS: {
  id: PowerUpType;
  name: string;
  keyLabel: string;
  icon: string;
  desc: string;
  gradient: string;
}[] = [
  {
    id: 'bomb',
    name: 'Bomb',
    keyLabel: '1',
    icon: '💣',
    desc: 'Explodes all bubbles in a 2-ring radius',
    gradient: 'from-rose-600 to-red-800',
  },
  {
    id: 'fireball',
    name: 'Fireball',
    keyLabel: '2',
    icon: '🔥',
    desc: 'Melts right through bubbles along path',
    gradient: 'from-amber-500 to-orange-700',
  },
  {
    id: 'rainbow',
    name: 'Rainbow',
    keyLabel: '3',
    icon: '🌈',
    desc: 'Matches any bubble color it contacts',
    gradient: 'from-pink-500 to-purple-700',
  },
  {
    id: 'lightning',
    name: 'Lightning',
    keyLabel: '4',
    icon: '⚡',
    desc: 'Clears the entire horizontal row',
    gradient: 'from-yellow-400 to-amber-600',
  },
];

export const PowerUpTray: React.FC<PowerUpTrayProps> = ({
  currentBubble,
  nextBubble,
  activePowerUp,
  inventory,
  onSelectPowerUp,
  onSwapBubbles,
}) => {
  const currentStyle = BUBBLE_STYLES[currentBubble];
  const nextStyle = BUBBLE_STYLES[nextBubble];

  return (
    <div className="w-full max-w-lg mx-auto px-3 py-2 bg-slate-900/90 backdrop-blur-md border-t border-slate-800 flex items-center justify-between gap-2 select-none">
      {/* Bubble Swap Controller */}
      <button
        onClick={onSwapBubbles}
        title="Swap Loaded & Next Bubbles (Spacebar)"
        className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 rounded-lg border border-slate-700 transition-all cursor-pointer group"
      >
        <div className="relative flex items-center">
          {/* Current Loaded bubble miniature */}
          <div
            className="w-5 h-5 rounded-full border border-white/40 shadow-sm"
            style={{
              background: `radial-gradient(circle at 35% 35%, ${currentStyle.highlight}, ${currentStyle.primary} 60%, ${currentStyle.secondary})`,
            }}
          />
          <ArrowLeftRight className="w-3.5 h-3.5 mx-1 text-sky-400 group-hover:rotate-180 transition-transform duration-300" />
          {/* Next bubble miniature */}
          <div
            className="w-4 h-4 rounded-full border border-white/30 opacity-80"
            style={{
              background: `radial-gradient(circle at 35% 35%, ${nextStyle.highlight}, ${nextStyle.primary} 60%, ${nextStyle.secondary})`,
            }}
          />
        </div>
        <div className="flex flex-col text-left leading-tight">
          <span className="text-[11px] font-bold text-white group-hover:text-sky-300">SWAP</span>
          <span className="text-[9px] text-slate-400 font-mono">[SPACE]</span>
        </div>
      </button>

      {/* Power-up Inventory Buttons */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {POWER_UPS.map((pu) => {
          const count = inventory[pu.id] || 0;
          const isActive = activePowerUp === pu.id;
          const hasAmmo = count > 0;

          return (
            <button
              key={pu.id}
              onClick={() => onSelectPowerUp(pu.id)}
              disabled={!hasAmmo && !isActive}
              title={`${pu.name} - ${pu.desc} (Press [${pu.keyLabel}])`}
              className={`relative flex flex-col items-center justify-center w-12 sm:w-14 py-1.5 rounded-lg border transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-b ' +
                    pu.gradient +
                    ' border-white shadow-[0_0_12px_rgba(255,255,255,0.4)] scale-105'
                  : hasAmmo
                  ? 'bg-slate-800 hover:bg-slate-750 border-slate-700 hover:border-slate-500'
                  : 'bg-slate-900/60 border-slate-800 opacity-40 cursor-not-allowed'
              }`}
            >
              {/* Power-up icon */}
              <span className="text-lg leading-none filter drop-shadow">{pu.icon}</span>

              {/* Ammo count badge */}
              <span
                className={`text-[10px] font-bold mt-0.5 ${
                  isActive ? 'text-white' : hasAmmo ? 'text-sky-300' : 'text-slate-500'
                }`}
              >
                {isActive ? 'ARMED' : `x${count}`}
              </span>

              {/* Keyboard hotkey indicator */}
              <span className="absolute -top-1.5 -right-1 text-[8px] font-mono bg-slate-950 text-slate-400 border border-slate-700 rounded px-1 leading-tight">
                {pu.keyLabel}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
