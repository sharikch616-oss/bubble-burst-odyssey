/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  BUBBLE_RADIUS,
  CANVAS_HEIGHT,
  CANVAS_WIDTH,
  CEILING_START_Y,
  DEFAULT_BUCKETS,
  DANGER_LINE_ROW,
  LAUNCHER_X,
  LAUNCHER_Y,
  MAX_GRID_ROWS,
  PROJECTILE_SPEED,
  ROW_HEIGHT,
} from '../game/constants';
import {
  Bubble,
  BubbleColor,
  DetachedBubble,
  FloatingText,
  LevelConfig,
  Particle,
  Point,
  PowerUpType,
  Projectile,
  ScoreBucket,
  StandardColor,
} from '../game/types';
import {
  calculateAimTrajectory,
  distance,
  findConnectedMatches,
  findDetachedBubbles,
  findSnapGridSlot,
  getBombBlastArea,
  getLightningRow,
  getNeighbors,
  gridToScreen,
} from '../game/physics';
import {
  drawAimGuide,
  drawBubble,
  drawBuckets,
  drawCeiling,
  drawDangerLine,
  drawDetachedBubbles,
  drawFloatingTexts,
  drawLauncher,
  drawParticles,
} from '../game/renderer';
import { sound } from '../game/audio';

interface GameCanvasProps {
  level: LevelConfig;
  aimGuideEnabled: boolean;
  activePowerUp: PowerUpType | null;
  currentBubble: BubbleColor;
  nextBubble: BubbleColor;
  onScoreUpdate: (points: number) => void;
  onMovesUpdate: (moves: number) => void;
  onCombosUpdate: (combo: number) => void;
  onVictory: (finalScore: number, bubblesLeft: number) => void;
  onGameOver: (reason: 'out_of_bubbles' | 'ceiling_breach', finalScore: number) => void;
  onAdvanceBubble: (newCurrent: BubbleColor, newNext: BubbleColor) => void;
  onConsumePowerUp: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  level,
  aimGuideEnabled,
  activePowerUp,
  currentBubble,
  nextBubble,
  onScoreUpdate,
  onMovesUpdate,
  onCombosUpdate,
  onVictory,
  onGameOver,
  onAdvanceBubble,
  onConsumePowerUp,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Core Game State Refs to maintain 60fps without React re-render lags
  const gridRef = useRef<(Bubble | null)[][]>([]);
  const ceilingYRef = useRef<number>(CEILING_START_Y);
  const foulsLeftRef = useRef<number>(level.foulsBeforeCeilingDrop);
  const movesRemainingRef = useRef<number>(level.bubbleLimit);
  const scoreRef = useRef<number>(0);
  const comboRef = useRef<number>(1);
  const aimAngleRef = useRef<number>(-Math.PI / 2);
  const projectileRef = useRef<Projectile | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const detachedBubblesRef = useRef<DetachedBubble[]>([]);
  const bucketsRef = useRef<ScoreBucket[]>(JSON.parse(JSON.stringify(DEFAULT_BUCKETS)));
  const recoilRef = useRef<number>(0);
  const isGameOverRef = useRef<boolean>(false);
  const isResolvingRef = useRef<boolean>(false);

  // Helper: Get list of colors currently remaining in the grid
  const getRemainingGridColors = useCallback((): StandardColor[] => {
    const present = new Set<StandardColor>();
    for (let r = 0; r < MAX_GRID_ROWS; r++) {
      for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
        const b = gridRef.current[r]?.[c];
        if (b && level.allowedColors.includes(b.color as StandardColor)) {
          present.add(b.color as StandardColor);
        }
      }
    }
    const arr = Array.from(present);
    return arr.length > 0 ? arr : level.allowedColors;
  }, [level.allowedColors]);

  // Helper: pick a random color from available
  const getRandomColor = useCallback((): StandardColor => {
    const colors = getRemainingGridColors();
    return colors[Math.floor(Math.random() * colors.length)];
  }, [getRemainingGridColors]);

  // Initialize level grid on level change
  useEffect(() => {
    const newGrid: (Bubble | null)[][] = [];
    ceilingYRef.current = CEILING_START_Y;
    foulsLeftRef.current = level.foulsBeforeCeilingDrop;
    movesRemainingRef.current = level.bubbleLimit;
    scoreRef.current = 0;
    comboRef.current = 1;
    projectileRef.current = null;
    particlesRef.current = [];
    floatingTextsRef.current = [];
    detachedBubblesRef.current = [];
    isGameOverRef.current = false;
    isResolvingRef.current = false;

    for (let r = 0; r < MAX_GRID_ROWS; r++) {
      newGrid[r] = [];
      const initRow = level.initialGrid[r];
      const maxCols = r % 2 === 0 ? 12 : 11;
      for (let c = 0; c < maxCols; c++) {
        const color = initRow ? initRow[c] : null;
        if (color) {
          const pt = gridToScreen(r, c, CEILING_START_Y);
          newGrid[r][c] = {
            id: `b_${r}_${c}_${Date.now()}_${Math.random()}`,
            row: r,
            col: c,
            color,
            x: pt.x,
            y: pt.y,
            scale: 1,
            alpha: 1,
          };
        } else {
          newGrid[r][c] = null;
        }
      }
    }

    gridRef.current = newGrid;
  }, [level]);

  // Add floating points text helper
  const addFloatingText = (x: number, y: number, text: string, color = '#fef08a', size = 16) => {
    floatingTextsRef.current.push({
      id: `${Date.now()}_${Math.random()}`,
      x,
      y,
      text,
      color,
      size,
      alpha: 1,
      vy: -1.8,
      life: 0,
    });
  };

  // Add explosion particles
  const addExplosion = (x: number, y: number, color: string, count = 14) => {
    // Burst shockwave ring
    particlesRef.current.push({
      x,
      y,
      vx: 0,
      vy: 0,
      color,
      size: 4,
      alpha: 0.9,
      life: 0,
      maxLife: 20,
      shape: 'ring',
    });

    // Sparks
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.5;
      const speed = Math.random() * 5 + 2;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: Math.random() * 3.5 + 2,
        alpha: 1,
        life: 0,
        maxLife: Math.random() * 25 + 20,
        shape: 'spark',
      });
    }
  };

  // Check if grid is cleared of target bubbles
  const checkVictoryCondition = () => {
    let activeBubbles = 0;
    for (let r = 0; r < MAX_GRID_ROWS; r++) {
      for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
        if (gridRef.current[r]?.[c] !== null) {
          activeBubbles++;
        }
      }
    }

    if (activeBubbles === 0 && !isGameOverRef.current) {
      isGameOverRef.current = true;
      sound.playVictory();
      const bonus = movesRemainingRef.current * 200;
      const finalScore = scoreRef.current + bonus;
      onScoreUpdate(finalScore);
      setTimeout(() => {
        onVictory(finalScore, movesRemainingRef.current);
      }, 500);
    }
  };

  // Check if bubbles crossed danger line
  const checkCeilingDanger = () => {
    const dangerY = ceilingYRef.current + DANGER_LINE_ROW * ROW_HEIGHT;
    for (let r = 0; r < MAX_GRID_ROWS; r++) {
      for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
        const b = gridRef.current[r]?.[c];
        if (b && b.y + BUBBLE_RADIUS >= dangerY) {
          isGameOverRef.current = true;
          sound.playGameOver();
          onGameOver('ceiling_breach', scoreRef.current);
          return true;
        }
      }
    }
    return false;
  };

  // Handle bubble placement and matches
  const handleBubbleLanded = (row: number, col: number, color: BubbleColor, powerUp?: PowerUpType) => {
    const grid = gridRef.current;
    const pt = gridToScreen(row, col, ceilingYRef.current);

    grid[row][col] = {
      id: `b_${row}_${col}_${Date.now()}`,
      row,
      col,
      color,
      x: pt.x,
      y: pt.y,
      scale: 1,
      alpha: 1,
    };

    let poppedCoords: { row: number; col: number }[] = [];

    if (powerUp === 'bomb' || color === 'bomb') {
      sound.playBomb();
      poppedCoords = getBombBlastArea(row, col, grid);
      addFloatingText(pt.x, pt.y - 10, 'BOMB BLAST!', '#f87171', 20);
    } else if (powerUp === 'lightning' || color === 'lightning') {
      sound.playLightning();
      poppedCoords = getLightningRow(row, grid);
      addFloatingText(pt.x, pt.y - 10, 'ROW ZAP!', '#facc15', 20);
    } else if (powerUp === 'rainbow' || color === 'rainbow') {
      sound.playRainbow();
      // Match all adjacent colors
      const neighbors = getNeighbors(row, col);
      poppedCoords = [{ row, col }];
      neighbors.forEach((n) => {
        if (grid[n.row]?.[n.col] !== null) {
          poppedCoords.push(n);
        }
      });
      addFloatingText(pt.x, pt.y - 10, 'PRISM SPLASH!', '#ec4899', 18);
    } else {
      // Standard match detection
      const matches = findConnectedMatches(row, col, grid);
      if (matches.length >= 3) {
        poppedCoords = matches;
      }
    }

    if (poppedCoords.length > 0) {
      // Successful match / blast!
      const currentCombo = comboRef.current;
      sound.playPop(currentCombo);

      const pointsEarned = poppedCoords.length * 100 * currentCombo;
      scoreRef.current += pointsEarned;
      onScoreUpdate(scoreRef.current);

      if (currentCombo > 1) {
        addFloatingText(pt.x, pt.y - 25, `COMBO x${currentCombo}!`, '#38bdf8', 18);
      }
      addFloatingText(pt.x, pt.y, `+${pointsEarned}`, '#fef08a', 16);

      // Remove popped bubbles & emit particles
      poppedCoords.forEach((c) => {
        const bubble = grid[c.row]?.[c.col];
        if (bubble) {
          addExplosion(bubble.x, bubble.y, '#38bdf8', 12);
          grid[c.row][c.col] = null;
        }
      });

      comboRef.current++;
      onCombosUpdate(comboRef.current);

      // Detach and drop floating clusters
      const detached = findDetachedBubbles(grid);
      if (detached.length > 0) {
        sound.playDetachedDrop();
        const dropBonus = detached.length * 150;
        scoreRef.current += dropBonus;
        onScoreUpdate(scoreRef.current);

        addFloatingText(pt.x, pt.y + 20, `DROP x${detached.length}! +${dropBonus}`, '#a7f3d0', 16);

        detached.forEach((coord) => {
          const b = grid[coord.row]?.[coord.col];
          if (b) {
            detachedBubblesRef.current.push({
              id: b.id,
              x: b.x,
              y: b.y,
              vx: (Math.random() - 0.5) * 4,
              vy: Math.random() * -2 - 1, // slight hop up before gravity drops
              color: b.color,
              rotation: 0,
              vRot: (Math.random() - 0.5) * 0.2,
              alpha: 1,
              bounced: 0,
            });
            grid[coord.row][coord.col] = null;
          }
        });
      }

      checkVictoryCondition();
    } else {
      // Missed match - Foul!
      sound.playBubbleLatch();
      comboRef.current = 1;
      onCombosUpdate(1);

      foulsLeftRef.current--;
      if (foulsLeftRef.current <= 0) {
        // Lower the ceiling!
        ceilingYRef.current += ROW_HEIGHT;
        foulsLeftRef.current = level.foulsBeforeCeilingDrop;

        // Recalculate screen positions of all grid bubbles
        for (let r = 0; r < MAX_GRID_ROWS; r++) {
          for (let c = 0; c < (grid[r]?.length || 0); c++) {
            const b = grid[r]?.[c];
            if (b) {
              const newPos = gridToScreen(r, c, ceilingYRef.current);
              b.y = newPos.y;
            }
          }
        }

        addFloatingText(CANVAS_WIDTH / 2, ceilingYRef.current + 30, 'CEILING LOWERED!', '#f87171', 18);
        checkCeilingDanger();
      }
    }

    // Moves check
    movesRemainingRef.current--;
    onMovesUpdate(movesRemainingRef.current);

    if (movesRemainingRef.current <= 0 && !isGameOverRef.current) {
      // Check if there are still bubbles on field
      let remainingBubbles = 0;
      for (let r = 0; r < MAX_GRID_ROWS; r++) {
        for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
          if (gridRef.current[r]?.[c] !== null) remainingBubbles++;
        }
      }

      if (remainingBubbles > 0) {
        isGameOverRef.current = true;
        sound.playGameOver();
        onGameOver('out_of_bubbles', scoreRef.current);
      }
    }

    // Advance launcher queue
    const remainingColors = getRemainingGridColors();
    const newNextColor = remainingColors[Math.floor(Math.random() * remainingColors.length)];
    onAdvanceBubble(nextBubble, newNextColor);
    isResolvingRef.current = false;
  };

  // Launch projectile
  const fireBubble = () => {
    if (
      projectileRef.current ||
      isResolvingRef.current ||
      isGameOverRef.current ||
      movesRemainingRef.current <= 0
    ) {
      return;
    }

    isResolvingRef.current = true;
    sound.playShoot();

    // Trigger cannon recoil
    recoilRef.current = 12;

    const angle = aimAngleRef.current;
    const vx = Math.cos(angle) * PROJECTILE_SPEED;
    const vy = Math.sin(angle) * PROJECTILE_SPEED;

    projectileRef.current = {
      x: LAUNCHER_X,
      y: LAUNCHER_Y,
      vx,
      vy,
      color: activePowerUp || currentBubble,
      active: true,
      powerUp: activePowerUp || undefined,
    };

    if (activePowerUp) {
      onConsumePowerUp();
    }
  };

  // Pointer input handling
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;

    const dx = mouseX - LAUNCHER_X;
    const dy = mouseY - LAUNCHER_Y;
    let angle = Math.atan2(dy, dx);

    // Clamp angle so player can only aim upwards (between -170 deg and -10 deg)
    const minAngle = -Math.PI + 0.15; // ~ -171 deg
    const maxAngle = -0.15; // ~ -9 deg
    if (angle > 0) {
      angle = dx < 0 ? minAngle : maxAngle;
    } else {
      angle = Math.max(minAngle, Math.min(maxAngle, angle));
    }

    aimAngleRef.current = angle;
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    handlePointerMove(e);
    fireBubble();
  };

  // Main 60fps Game Animation Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      animId = requestAnimationFrame(loop);
      const dt = currentTime - lastTime;
      lastTime = currentTime;

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // 1. CLEAR CANVAS
      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Deep arcade table background
      const bgGrad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
      bgGrad.addColorStop(0, '#090d16');
      bgGrad.addColorStop(0.5, '#0f172a');
      bgGrad.addColorStop(1, '#020617');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Subtle background grid stars / dust
      ctx.fillStyle = 'rgba(56, 189, 248, 0.05)';
      for (let i = 0; i < 20; i++) {
        const sx = ((i * 123 + currentTime * 0.01) % CANVAS_WIDTH);
        const sy = ((i * 321 + currentTime * 0.005) % CANVAS_HEIGHT);
        ctx.fillRect(sx, sy, 2, 2);
      }

      // 2. UPDATE PROJECTILE PHYSICS
      const proj = projectileRef.current;
      if (proj && proj.active) {
        proj.x += proj.vx;
        proj.y += proj.vy;

        // Left/Right wall bounce
        if (proj.x - BUBBLE_RADIUS <= 0) {
          proj.x = BUBBLE_RADIUS;
          proj.vx = -proj.vx;
          sound.playWallBounce();
        } else if (proj.x + BUBBLE_RADIUS >= CANVAS_WIDTH) {
          proj.x = CANVAS_WIDTH - BUBBLE_RADIUS;
          proj.vx = -proj.vx;
          sound.playWallBounce();
        }

        // Fireball piercing special logic
        if (proj.powerUp === 'fireball') {
          sound.playFireball();
          addExplosion(proj.x, proj.y, '#f97316', 4);

          // Obliterate any bubbles in contact along path
          for (let r = 0; r < MAX_GRID_ROWS; r++) {
            for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
              const b = gridRef.current[r]?.[c];
              if (b && distance({ x: proj.x, y: proj.y }, { x: b.x, y: b.y }) <= BUBBLE_RADIUS * 1.8) {
                addExplosion(b.x, b.y, '#ea580c', 10);
                gridRef.current[r][c] = null;
                scoreRef.current += 150;
                onScoreUpdate(scoreRef.current);
              }
            }
          }

          // Stops at ceiling
          if (proj.y - BUBBLE_RADIUS <= ceilingYRef.current) {
            proj.active = false;
            projectileRef.current = null;
            const detached = findDetachedBubbles(gridRef.current);
            if (detached.length > 0) {
              sound.playDetachedDrop();
              detached.forEach((coord) => {
                const b = gridRef.current[coord.row]?.[coord.col];
                if (b) {
                  detachedBubblesRef.current.push({
                    id: b.id,
                    x: b.x,
                    y: b.y,
                    vx: (Math.random() - 0.5) * 4,
                    vy: Math.random() * -2,
                    color: b.color,
                    rotation: 0,
                    vRot: 0.1,
                    alpha: 1,
                    bounced: 0,
                  });
                  gridRef.current[coord.row][coord.col] = null;
                }
              });
            }
            checkVictoryCondition();
            isResolvingRef.current = false;
          }
        } else {
          // Standard / Bomb / Lightning / Rainbow collision check
          let hitGrid = false;

          // Check ceiling hit
          if (proj.y - BUBBLE_RADIUS <= ceilingYRef.current) {
            hitGrid = true;
          } else {
            // Check collision with any existing bubble
            for (let r = 0; r < MAX_GRID_ROWS; r++) {
              for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
                const b = gridRef.current[r]?.[c];
                if (b) {
                  const d = distance({ x: proj.x, y: proj.y }, { x: b.x, y: b.y });
                  if (d <= BUBBLE_RADIUS * 1.85) {
                    hitGrid = true;
                    break;
                  }
                }
              }
              if (hitGrid) break;
            }
          }

          if (hitGrid) {
            proj.active = false;
            const targetSlot = findSnapGridSlot(
              proj.x,
              proj.y,
              gridRef.current,
              ceilingYRef.current
            );

            if (targetSlot) {
              handleBubbleLanded(
                targetSlot.row,
                targetSlot.col,
                proj.color,
                proj.powerUp
              );
            }
            projectileRef.current = null;
          }
        }
      }

      // 3. UPDATE DETACHED FALLING BUBBLES
      const gravity = 0.38;
      for (let i = detachedBubblesRef.current.length - 1; i >= 0; i--) {
        const b = detachedBubblesRef.current[i];
        b.x += b.vx;
        b.y += b.vy;
        b.vy += gravity;
        b.rotation += b.vRot;

        // Bounce on side walls
        if (b.x <= BUBBLE_RADIUS || b.x >= CANVAS_WIDTH - BUBBLE_RADIUS) {
          b.vx = -b.vx * 0.7;
        }

        // Check if landed in bottom buckets
        if (b.y >= CANVAS_HEIGHT - 35) {
          // Find matching bucket
          const bucket = bucketsRef.current.find(
            (bk) => b.x >= bk.x && b.x <= bk.x + bk.width
          );
          if (bucket) {
            bucket.hitAnim = 1.0;
            sound.playBucketHit(bucket.points);
            scoreRef.current += bucket.points;
            onScoreUpdate(scoreRef.current);
            addFloatingText(b.x, CANVAS_HEIGHT - 50, `+${bucket.points}`, '#38bdf8', 16);
            addExplosion(b.x, CANVAS_HEIGHT - 35, '#38bdf8', 8);
          }
          detachedBubblesRef.current.splice(i, 1);
        }
      }

      // Update bucket hit animations
      bucketsRef.current.forEach((bk) => {
        if (bk.hitAnim > 0) {
          bk.hitAnim = Math.max(0, bk.hitAnim - 0.05);
        }
      });

      // 4. UPDATE PARTICLES & TEXTS
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        p.alpha = 1 - p.life / p.maxLife;
        if (p.shape === 'ring') {
          p.size += 2.5;
        } else {
          p.vy += 0.15; // spark gravity
        }
        if (p.life >= p.maxLife) {
          particlesRef.current.splice(i, 1);
        }
      }

      for (let i = floatingTextsRef.current.length - 1; i >= 0; i--) {
        const t = floatingTextsRef.current[i];
        t.y += t.vy;
        t.life++;
        t.alpha = Math.max(0, 1 - t.life / 40);
        if (t.life >= 40) {
          floatingTextsRef.current.splice(i, 1);
        }
      }

      // Cannon recoil recovery
      if (recoilRef.current > 0) {
        recoilRef.current = Math.max(0, recoilRef.current - 1.2);
      }

      // 5. RENDER GAME ELEMENTS
      // A. Aim Guide
      if (aimGuideEnabled && !projectileRef.current && !isResolvingRef.current) {
        const trajectory = calculateAimTrajectory(
          LAUNCHER_X,
          LAUNCHER_Y,
          aimAngleRef.current,
          gridRef.current,
          ceilingYRef.current
        );
        drawAimGuide(
          ctx,
          trajectory,
          activePowerUp || currentBubble,
          currentTime
        );
      }

      // B. Danger threshold line
      drawDangerLine(ctx, ceilingYRef.current, currentTime);

      // C. Active Grid Bubbles
      for (let r = 0; r < MAX_GRID_ROWS; r++) {
        for (let c = 0; c < (gridRef.current[r]?.length || 0); c++) {
          const b = gridRef.current[r]?.[c];
          if (b) {
            drawBubble(ctx, b.x, b.y, b.color, BUBBLE_RADIUS, b.alpha, b.scale);
          }
        }
      }

      // D. Detached Bubbles
      drawDetachedBubbles(ctx, detachedBubblesRef.current);

      // E. Flying Projectile
      if (projectileRef.current && projectileRef.current.active) {
        drawBubble(
          ctx,
          projectileRef.current.x,
          projectileRef.current.y,
          projectileRef.current.color,
          BUBBLE_RADIUS
        );
      }

      // F. Ceiling Bar
      drawCeiling(
        ctx,
        ceilingYRef.current,
        foulsLeftRef.current,
        level.foulsBeforeCeilingDrop
      );

      // G. Particles & Floaters
      drawParticles(ctx, particlesRef.current);
      drawFloatingTexts(ctx, floatingTextsRef.current);

      // H. Bottom Score Buckets
      drawBuckets(ctx, bucketsRef.current, currentTime);

      // I. Cannon Launcher Turret
      drawLauncher(
        ctx,
        aimAngleRef.current,
        activePowerUp || currentBubble,
        nextBubble,
        recoilRef.current,
        currentTime
      );
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [
    level,
    aimGuideEnabled,
    activePowerUp,
    currentBubble,
    nextBubble,
    onAdvanceBubble,
    onCombosUpdate,
    onConsumePowerUp,
    onGameOver,
    onMovesUpdate,
    onScoreUpdate,
    onVictory,
    getRemainingGridColors,
  ]);

  return (
    <div className="relative w-full flex items-center justify-center p-1 sm:p-2 select-none touch-none">
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="rounded-xl shadow-2xl border border-slate-800 cursor-crosshair max-w-full max-h-[82vh] aspect-[460/680] object-contain bg-slate-950"
      />
    </div>
  );
};
