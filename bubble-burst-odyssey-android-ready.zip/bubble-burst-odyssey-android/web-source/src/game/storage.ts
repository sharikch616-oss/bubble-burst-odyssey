/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PowerUpType, UserProgress } from './types';

const STORAGE_KEY = 'bubble_burst_prism_progress_v1';

const DEFAULT_PROGRESS: UserProgress = {
  unlockedLevel: 1,
  levelStars: {},
  levelHighScores: {},
  powerUpInventory: {
    bomb: 3,
    fireball: 2,
    rainbow: 2,
    lightning: 2,
  },
  soundEnabled: true,
  aimGuideEnabled: true,
};

export function loadProgress(): UserProgress {
  if (typeof window === 'undefined') return DEFAULT_PROGRESS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_PROGRESS,
      ...parsed,
      powerUpInventory: {
        ...DEFAULT_PROGRESS.powerUpInventory,
        ...(parsed.powerUpInventory || {}),
      },
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveProgress(progress: UserProgress): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // ignore quota errors
  }
}

export function recordLevelResult(
  levelId: number,
  score: number,
  stars: number
): UserProgress {
  const current = loadProgress();
  const prevHighScore = current.levelHighScores[levelId] || 0;
  const prevStars = current.levelStars[levelId] || 0;

  current.levelHighScores[levelId] = Math.max(prevHighScore, score);
  current.levelStars[levelId] = Math.max(prevStars, stars);

  // If level cleared with >= 1 star, unlock next level
  if (stars >= 1 && levelId >= current.unlockedLevel) {
    current.unlockedLevel = Math.min(12, levelId + 1);
  }

  // Award bonus power-ups for high stars
  if (stars === 3) {
    const keys: PowerUpType[] = ['bomb', 'fireball', 'rainbow', 'lightning'];
    const randomKey = keys[Math.floor(Math.random() * keys.length)];
    current.powerUpInventory[randomKey] = (current.powerUpInventory[randomKey] || 0) + 1;
  }

  saveProgress(current);
  return current;
}
