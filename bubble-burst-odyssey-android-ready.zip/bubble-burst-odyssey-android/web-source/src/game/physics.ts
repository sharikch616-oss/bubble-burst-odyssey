/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  BUBBLE_RADIUS,
  CANVAS_WIDTH,
  COLS_EVEN,
  COLS_ODD,
  ROW_HEIGHT,
  MAX_GRID_ROWS,
} from './constants';
import { Bubble, BubbleColor, GridCoord, Point } from './types';

export const MARGIN_X = (CANVAS_WIDTH - COLS_EVEN * (BUBBLE_RADIUS * 2)) / 2;

/**
 * Converts grid coordinate (row, col) to screen pixel coordinates (x, y)
 */
export function gridToScreen(row: number, col: number, ceilingY: number): Point {
  const isEven = row % 2 === 0;
  const x = isEven
    ? MARGIN_X + col * (BUBBLE_RADIUS * 2) + BUBBLE_RADIUS
    : MARGIN_X + BUBBLE_RADIUS + col * (BUBBLE_RADIUS * 2) + BUBBLE_RADIUS;
  const y = ceilingY + row * ROW_HEIGHT + BUBBLE_RADIUS;
  return { x, y };
}

/**
 * Returns the maximum column count for a given row in hexagonal layout
 */
export function getColCount(row: number): number {
  return row % 2 === 0 ? COLS_EVEN : COLS_ODD;
}

/**
 * Finds all valid neighboring hexagonal coordinates for a given row and col
 */
export function getNeighbors(row: number, col: number): GridCoord[] {
  const isEven = row % 2 === 0;
  const candidates: [number, number][] = isEven
    ? [
        [row, col - 1], // Left
        [row, col + 1], // Right
        [row - 1, col - 1], // Top-Left
        [row - 1, col], // Top-Right
        [row + 1, col - 1], // Bottom-Left
        [row + 1, col], // Bottom-Right
      ]
    : [
        [row, col - 1], // Left
        [row, col + 1], // Right
        [row - 1, col], // Top-Left
        [row - 1, col + 1], // Top-Right
        [row + 1, col], // Bottom-Left
        [row + 1, col + 1], // Bottom-Right
      ];

  return candidates
    .filter(([r, c]) => {
      if (r < 0 || r >= MAX_GRID_ROWS) return false;
      const maxCols = getColCount(r);
      return c >= 0 && c < maxCols;
    })
    .map(([r, c]) => ({ row: r, col: c }));
}

/**
 * Distance between two points
 */
export function distance(p1: Point, p2: Point): number {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Finds the best empty grid cell to snap a projectile into upon collision
 */
export function findSnapGridSlot(
  x: number,
  y: number,
  grid: (Bubble | null)[][],
  ceilingY: number
): GridCoord | null {
  // If projectile hit ceiling directly
  if (y <= ceilingY + BUBBLE_RADIUS * 1.5) {
    let bestCol = 0;
    let minD = Infinity;
    for (let c = 0; c < COLS_EVEN; c++) {
      if (!grid[0] || !grid[0][c]) {
        const pt = gridToScreen(0, c, ceilingY);
        const d = Math.abs(pt.x - x);
        if (d < minD) {
          minD = d;
          bestCol = c;
        }
      }
    }
    return { row: 0, col: bestCol };
  }

  let bestCoord: GridCoord | null = null;
  let minDistance = Infinity;

  // Search around the vicinity of coordinates
  for (let r = 0; r < MAX_GRID_ROWS; r++) {
    const maxCols = getColCount(r);
    for (let c = 0; c < maxCols; c++) {
      if (grid[r] && grid[r][c] !== null) continue; // occupied

      // Candidate must be adjacent to at least one occupied bubble OR row 0
      const neighbors = getNeighbors(r, c);
      const hasAdjacentAnchor =
        r === 0 || neighbors.some((n) => grid[n.row] && grid[n.row][n.col] !== null);

      if (!hasAdjacentAnchor) continue;

      const cellPos = gridToScreen(r, c, ceilingY);
      const d = distance({ x, y }, cellPos);
      if (d < minDistance) {
        minDistance = d;
        bestCoord = { row: r, col: c };
      }
    }
  }

  return bestCoord;
}

/**
 * Finds all contiguous bubbles matching the given color (Breadth First Search)
 */
export function findConnectedMatches(
  startRow: number,
  startCol: number,
  grid: (Bubble | null)[][]
): GridCoord[] {
  const startBubble = grid[startRow]?.[startCol];
  if (!startBubble) return [];

  const targetColor = startBubble.color;
  const visited = new Set<string>();
  const matches: GridCoord[] = [];
  const queue: GridCoord[] = [{ row: startRow, col: startCol }];

  visited.add(`${startRow},${startCol}`);

  while (queue.length > 0) {
    const current = queue.shift()!;
    matches.push(current);

    const neighbors = getNeighbors(current.row, current.col);
    for (const nb of neighbors) {
      const key = `${nb.row},${nb.col}`;
      if (visited.has(key)) continue;

      const neighborBubble = grid[nb.row]?.[nb.col];
      if (neighborBubble && neighborBubble.color === targetColor) {
        visited.add(key);
        queue.push(nb);
      }
    }
  }

  return matches;
}

/**
 * Finds all floating / unanchored bubbles that have lost connection to row 0
 */
export function findDetachedBubbles(grid: (Bubble | null)[][]): GridCoord[] {
  const visited = new Set<string>();
  const queue: GridCoord[] = [];

  // Seed BFS with all active bubbles in Row 0 (the ceiling anchor)
  if (grid[0]) {
    for (let c = 0; c < COLS_EVEN; c++) {
      if (grid[0][c] !== null) {
        visited.add(`0,${c}`);
        queue.push({ row: 0, col: c });
      }
    }
  }

  // Traverse through all connected bubbles
  while (queue.length > 0) {
    const curr = queue.shift()!;
    const neighbors = getNeighbors(curr.row, curr.col);

    for (const nb of neighbors) {
      const key = `${nb.row},${nb.col}`;
      if (!visited.has(key) && grid[nb.row]?.[nb.col] !== null) {
        visited.add(key);
        queue.push(nb);
      }
    }
  }

  // Any occupied cell not visited is an unanchored / floating bubble!
  const detached: GridCoord[] = [];
  for (let r = 0; r < MAX_GRID_ROWS; r++) {
    const maxCols = getColCount(r);
    for (let c = 0; c < maxCols; c++) {
      if (grid[r] && grid[r][c] !== null && !visited.has(`${r},${c}`)) {
        detached.push({ row: r, col: c });
      }
    }
  }

  return detached;
}

/**
 * Find bomb blast coordinates (2-ring radius)
 */
export function getBombBlastArea(row: number, col: number, grid: (Bubble | null)[][]): GridCoord[] {
  const result = new Set<string>();
  const firstRing = getNeighbors(row, col);

  result.add(`${row},${col}`);
  for (const n1 of firstRing) {
    result.add(`${n1.row},${n1.col}`);
    const secondRing = getNeighbors(n1.row, n1.col);
    for (const n2 of secondRing) {
      result.add(`${n2.row},${n2.col}`);
    }
  }

  const coords: GridCoord[] = [];
  result.forEach((key) => {
    const [r, c] = key.split(',').map(Number);
    if (grid[r] && grid[r][c] !== null) {
      coords.push({ row: r, col: c });
    }
  });

  return coords;
}

/**
 * Get entire row for lightning zap
 */
export function getLightningRow(row: number, grid: (Bubble | null)[][]): GridCoord[] {
  const coords: GridCoord[] = [];
  const maxCols = getColCount(row);
  for (let c = 0; c < maxCols; c++) {
    if (grid[row] && grid[row][c] !== null) {
      coords.push({ row, col: c });
    }
  }
  return coords;
}

/**
 * Calculate trajectory points for aiming guide including bank reflections
 */
export function calculateAimTrajectory(
  startX: number,
  startY: number,
  angle: number,
  grid: (Bubble | null)[][],
  ceilingY: number,
  maxSegments = 3
): Point[] {
  const points: Point[] = [{ x: startX, y: startY }];
  let curX = startX;
  let curY = startY;
  let vx = Math.cos(angle);
  let vy = Math.sin(angle);

  // Must shoot upwards
  if (vy >= -0.05) return points;

  const step = 4;
  let currentSegment = 0;

  for (let i = 0; i < 700; i++) {
    curX += vx * step;
    curY += vy * step;

    // Left wall bounce
    if (curX <= BUBBLE_RADIUS) {
      curX = BUBBLE_RADIUS;
      vx = -vx;
      points.push({ x: curX, y: curY });
      currentSegment++;
      if (currentSegment >= maxSegments) break;
    }
    // Right wall bounce
    else if (curX >= CANVAS_WIDTH - BUBBLE_RADIUS) {
      curX = CANVAS_WIDTH - BUBBLE_RADIUS;
      vx = -vx;
      points.push({ x: curX, y: curY });
      currentSegment++;
      if (currentSegment >= maxSegments) break;
    }

    // Hit ceiling
    if (curY <= ceilingY + BUBBLE_RADIUS) {
      points.push({ x: curX, y: ceilingY + BUBBLE_RADIUS });
      break;
    }

    // Check collision with any existing bubble
    let collided = false;
    for (let r = 0; r < MAX_GRID_ROWS; r++) {
      const maxCols = getColCount(r);
      for (let c = 0; c < maxCols; c++) {
        const bubble = grid[r]?.[c];
        if (bubble) {
          const d = distance({ x: curX, y: curY }, { x: bubble.x, y: bubble.y });
          if (d <= BUBBLE_RADIUS * 1.85) {
            collided = true;
            break;
          }
        }
      }
      if (collided) break;
    }

    if (collided) {
      points.push({ x: curX, y: curY });
      break;
    }
  }

  return points;
}
