/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  BUBBLE_RADIUS,
  BUBBLE_STYLES,
  CANVAS_HEIGHT,
  CANVAS_WIDTH,
  DANGER_LINE_ROW,
  LAUNCHER_X,
  LAUNCHER_Y,
  NEXT_BUBBLE_X,
  NEXT_BUBBLE_Y,
  ROW_HEIGHT,
} from './constants';
import {
  Bubble,
  BubbleColor,
  DetachedBubble,
  FloatingText,
  Particle,
  Point,
  Projectile,
  ScoreBucket,
} from './types';

/**
 * Draws a gorgeous, juicy 3D glossy bubble with specular highlights
 */
export function drawBubble(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: BubbleColor,
  radius = BUBBLE_RADIUS,
  alpha = 1,
  scale = 1
) {
  if (alpha <= 0.01) return;

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  if (scale !== 1) {
    ctx.scale(scale, scale);
  }

  const style = BUBBLE_STYLES[color] || BUBBLE_STYLES.blue;

  // Outer ambient shadow
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.shadowColor = style.glow;
  ctx.shadowBlur = 8;
  ctx.fillStyle = style.secondary;
  ctx.fill();
  ctx.shadowBlur = 0;

  // Main 3D Sphere Radial Gradient
  const sphereGrad = ctx.createRadialGradient(
    -radius * 0.35,
    -radius * 0.35,
    radius * 0.1,
    0,
    0,
    radius
  );
  sphereGrad.addColorStop(0, style.highlight);
  sphereGrad.addColorStop(0.35, style.primary);
  sphereGrad.addColorStop(0.85, style.secondary);
  sphereGrad.addColorStop(1, style.secondary);

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fillStyle = sphereGrad;
  ctx.fill();

  // Special bubble unique decorations
  if (color === 'rainbow') {
    // Shimmering rainbow ring
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.65, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 2;
    ctx.stroke();
  } else if (color === 'stone') {
    // Stone cracks
    ctx.beginPath();
    ctx.moveTo(-radius * 0.4, -radius * 0.2);
    ctx.lineTo(radius * 0.1, radius * 0.1);
    ctx.lineTo(radius * 0.4, -radius * 0.3);
    ctx.moveTo(radius * 0.1, radius * 0.1);
    ctx.lineTo(-radius * 0.1, radius * 0.5);
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.6)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  // Bottom subtle ambient backlight reflection
  ctx.beginPath();
  ctx.ellipse(
    radius * 0.1,
    radius * 0.45,
    radius * 0.5,
    radius * 0.18,
    0,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
  ctx.fill();

  // Top-left primary specular highlight (gloss glare)
  ctx.beginPath();
  ctx.ellipse(
    -radius * 0.32,
    -radius * 0.36,
    radius * 0.38,
    radius * 0.2,
    -Math.PI / 4,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = 'rgba(255, 255, 255, 0.82)';
  ctx.fill();

  // Secondary pin-point gloss dot
  ctx.beginPath();
  ctx.arc(-radius * 0.1, -radius * 0.52, radius * 0.1, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.fill();

  // Bubble Icon if applicable (bomb, lightning, etc.)
  if (style.icon) {
    ctx.font = `${Math.floor(radius * 1.05)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
    ctx.shadowBlur = 4;
    ctx.fillText(style.icon, 0, 1);
    ctx.shadowBlur = 0;
  }

  ctx.restore();
}

/**
 * Draws the dynamic dotted trajectory aiming guide
 */
export function drawAimGuide(
  ctx: CanvasRenderingContext2D,
  trajectory: Point[],
  activeColor: BubbleColor,
  time: number
) {
  if (trajectory.length < 2) return;

  const style = BUBBLE_STYLES[activeColor] || BUBBLE_STYLES.blue;

  ctx.save();
  ctx.strokeStyle = style.highlight;
  ctx.shadowColor = style.glow;
  ctx.shadowBlur = 6;
  ctx.lineWidth = 2.5;
  ctx.setLineDash([6, 8]);
  ctx.lineDashOffset = -time * 0.04;

  ctx.beginPath();
  ctx.moveTo(trajectory[0].x, trajectory[0].y);
  for (let i = 1; i < trajectory.length; i++) {
    ctx.lineTo(trajectory[i].x, trajectory[i].y);
  }
  ctx.stroke();

  // Landing point indicator ring
  const endPt = trajectory[trajectory.length - 1];
  const pulse = Math.sin(time * 0.008) * 3;
  ctx.beginPath();
  ctx.arc(endPt.x, endPt.y, BUBBLE_RADIUS + pulse, 0, Math.PI * 2);
  ctx.setLineDash([]);
  ctx.strokeStyle = style.highlight;
  ctx.lineWidth = 2;
  ctx.stroke();

  // Center landing dot
  ctx.beginPath();
  ctx.arc(endPt.x, endPt.y, 4, 0, Math.PI * 2);
  ctx.fillStyle = style.highlight;
  ctx.fill();

  ctx.restore();
}

/**
 * Draws the bottom cannon launcher turret
 */
export function drawLauncher(
  ctx: CanvasRenderingContext2D,
  aimAngle: number,
  currentBubbleColor: BubbleColor,
  nextBubbleColor: BubbleColor,
  recoilOffset = 0,
  time: number
) {
  ctx.save();

  // Base platform circle
  ctx.beginPath();
  ctx.arc(LAUNCHER_X, LAUNCHER_Y + 14, 44, 0, Math.PI * 2);
  const baseGrad = ctx.createRadialGradient(
    LAUNCHER_X,
    LAUNCHER_Y + 14,
    5,
    LAUNCHER_X,
    LAUNCHER_Y + 14,
    44
  );
  baseGrad.addColorStop(0, '#1e293b');
  baseGrad.addColorStop(0.7, '#0f172a');
  baseGrad.addColorStop(1, '#020617');
  ctx.fillStyle = baseGrad;
  ctx.fill();
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Rotating brass/cyan cannon barrel
  ctx.save();
  ctx.translate(LAUNCHER_X, LAUNCHER_Y);
  ctx.rotate(aimAngle + Math.PI / 2); // default vertical is -PI/2, rotate so barrel points along angle

  // Recoil translation along barrel axis
  ctx.translate(0, recoilOffset);

  // Barrel shadow
  ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
  ctx.shadowBlur = 10;

  // Barrel body
  const barrelGrad = ctx.createLinearGradient(-14, 0, 14, 0);
  barrelGrad.addColorStop(0, '#334155');
  barrelGrad.addColorStop(0.3, '#64748b');
  barrelGrad.addColorStop(0.7, '#cbd5e1');
  barrelGrad.addColorStop(1, '#334155');

  ctx.fillStyle = barrelGrad;
  ctx.beginPath();
  ctx.roundRect(-12, -42, 24, 42, [4, 4, 0, 0]);
  ctx.fill();

  // Cannon muzzle ring
  ctx.fillStyle = '#0284c7';
  ctx.fillRect(-14, -46, 28, 6);

  ctx.shadowBlur = 0;
  ctx.restore();

  // Current loaded bubble in the chamber
  drawBubble(ctx, LAUNCHER_X, LAUNCHER_Y, currentBubbleColor, BUBBLE_RADIUS);

  // Next bubble pedestal
  const nextBob = Math.sin(time * 0.005) * 2;
  ctx.beginPath();
  ctx.arc(NEXT_BUBBLE_X, NEXT_BUBBLE_Y + 10, 24, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
  ctx.fill();
  ctx.strokeStyle = '#475569';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Next label
  ctx.font = '10px sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.textAlign = 'center';
  ctx.fillText('NEXT', NEXT_BUBBLE_X, NEXT_BUBBLE_Y + 28);

  // Next bubble preview
  drawBubble(
    ctx,
    NEXT_BUBBLE_X,
    NEXT_BUBBLE_Y + nextBob,
    nextBubbleColor,
    BUBBLE_RADIUS * 0.8
  );

  // Swap arrows icon between next and current
  ctx.font = '14px sans-serif';
  ctx.fillStyle = '#38bdf8';
  ctx.textAlign = 'center';
  ctx.fillText('⇄', (LAUNCHER_X + NEXT_BUBBLE_X) / 2, LAUNCHER_Y + 6);

  ctx.restore();
}

/**
 * Draws the descending ceiling bar with hazard stripes
 */
export function drawCeiling(
  ctx: CanvasRenderingContext2D,
  ceilingY: number,
  foulsLeft: number,
  maxFouls: number
) {
  ctx.save();

  // Ceiling bar body
  const barHeight = 22;
  const barY = ceilingY - barHeight;

  // Background plate
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, 0, CANVAS_WIDTH, ceilingY);

  // Metal edge trim
  const edgeGrad = ctx.createLinearGradient(0, barY, 0, ceilingY);
  edgeGrad.addColorStop(0, '#334155');
  edgeGrad.addColorStop(0.5, '#475569');
  edgeGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = edgeGrad;
  ctx.fillRect(0, barY, CANVAS_WIDTH, barHeight);

  // Hazard diagonal stripes
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, barY, CANVAS_WIDTH, barHeight);
  ctx.clip();
  ctx.fillStyle = '#f59e0b';
  for (let x = -20; x < CANVAS_WIDTH + 40; x += 36) {
    ctx.beginPath();
    ctx.moveTo(x, barY);
    ctx.lineTo(x + 12, barY);
    ctx.lineTo(x - 6, ceilingY);
    ctx.lineTo(x - 18, ceilingY);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // Ceiling bottom border glow
  ctx.beginPath();
  ctx.moveTo(0, ceilingY);
  ctx.lineTo(CANVAS_WIDTH, ceilingY);
  ctx.strokeStyle = '#f59e0b';
  ctx.shadowColor = 'rgba(245, 158, 11, 0.6)';
  ctx.shadowBlur = 6;
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Foul warning dots in top center
  ctx.font = '10px sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.textAlign = 'center';
  ctx.fillText('CEILING DROP IN:', CANVAS_WIDTH / 2 - 35, 14);

  for (let i = 0; i < maxFouls; i++) {
    const dotX = CANVAS_WIDTH / 2 + 20 + i * 14;
    const dotY = 11;
    ctx.beginPath();
    ctx.arc(dotX, dotY, 4, 0, Math.PI * 2);
    if (i < foulsLeft) {
      ctx.fillStyle = '#10b981';
    } else {
      ctx.fillStyle = '#ef4444';
    }
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Draws the bottom arcade score pots / buckets
 */
export function drawBuckets(
  ctx: CanvasRenderingContext2D,
  buckets: ScoreBucket[],
  time: number
) {
  const bucketY = CANVAS_HEIGHT - 32;
  const bucketH = 32;

  ctx.save();
  buckets.forEach((bucket, idx) => {
    const isHit = bucket.hitAnim > 0.05;
    const bgGrad = ctx.createLinearGradient(0, bucketY, 0, CANVAS_HEIGHT);

    if (isHit) {
      bgGrad.addColorStop(0, '#f59e0b');
      bgGrad.addColorStop(1, '#78350f');
    } else {
      bgGrad.addColorStop(0, idx % 2 === 0 ? '#1e293b' : '#0f172a');
      bgGrad.addColorStop(1, '#020617');
    }

    ctx.fillStyle = bgGrad;
    ctx.fillRect(bucket.x, bucketY, bucket.width, bucketH);

    // Separator line
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.strokeRect(bucket.x, bucketY, bucket.width, bucketH);

    // Bucket score value label
    ctx.font = 'bold 12px sans-serif';
    ctx.fillStyle = isHit ? '#ffffff' : '#38bdf8';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = isHit ? 'rgba(255, 255, 255, 0.8)' : 'rgba(56, 189, 248, 0.4)';
    ctx.shadowBlur = isHit ? 8 : 4;
    ctx.fillText(`+${bucket.points}`, bucket.x + bucket.width / 2, bucketY + bucketH / 2);
    ctx.shadowBlur = 0;
  });
  ctx.restore();
}

/**
 * Draws the danger line threshold near the bottom
 */
export function drawDangerLine(
  ctx: CanvasRenderingContext2D,
  ceilingY: number,
  time: number
) {
  const dangerY = ceilingY + DANGER_LINE_ROW * ROW_HEIGHT;
  const pulse = Math.sin(time * 0.005) * 0.2 + 0.35;

  ctx.save();
  ctx.strokeStyle = `rgba(239, 68, 68, ${pulse})`;
  ctx.lineWidth = 1.5;
  ctx.setLineDash([8, 6]);
  ctx.beginPath();
  ctx.moveTo(0, dangerY);
  ctx.lineTo(CANVAS_WIDTH, dangerY);
  ctx.stroke();

  ctx.font = '9px sans-serif';
  ctx.fillStyle = `rgba(239, 68, 68, ${pulse + 0.2})`;
  ctx.textAlign = 'right';
  ctx.fillText('DANGER THRESHOLD', CANVAS_WIDTH - 8, dangerY - 4);
  ctx.restore();
}

/**
 * Renders all active particles (burst sparks, rings, shockwaves)
 */
export function drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[]) {
  ctx.save();
  for (const p of particles) {
    if (p.alpha <= 0.01) continue;
    ctx.globalAlpha = p.alpha;
    ctx.fillStyle = p.color;

    if (p.shape === 'ring') {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

/**
 * Renders floating score popups (+150, COMBO x2)
 */
export function drawFloatingTexts(
  ctx: CanvasRenderingContext2D,
  texts: FloatingText[]
) {
  ctx.save();
  for (const t of texts) {
    if (t.alpha <= 0.01) continue;
    ctx.globalAlpha = t.alpha;
    ctx.font = `bold ${t.size}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = t.color;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
    ctx.shadowBlur = 6;
    ctx.fillText(t.text, t.x, t.y);
  }
  ctx.restore();
}

/**
 * Renders falling unanchored bubbles
 */
export function drawDetachedBubbles(
  ctx: CanvasRenderingContext2D,
  detached: DetachedBubble[]
) {
  for (const b of detached) {
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(b.rotation);
    drawBubble(ctx, 0, 0, b.color, BUBBLE_RADIUS, b.alpha);
    ctx.restore();
  }
}
