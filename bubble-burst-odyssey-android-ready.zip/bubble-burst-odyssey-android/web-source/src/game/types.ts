/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type StandardColor = 'red' | 'blue' | 'green' | 'yellow' | 'purple' | 'cyan';
export type SpecialColor = 'bomb' | 'fireball' | 'rainbow' | 'lightning' | 'stone';
export type BubbleColor = StandardColor | SpecialColor;

export type PowerUpType = 'bomb' | 'fireball' | 'rainbow' | 'lightning';

export interface BubbleVisualConfig {
  primary: string;
  secondary: string;
  highlight: string;
  glow: string;
  icon?: string;
}

export interface GridCoord {
  row: number;
  col: number;
}

export interface Point {
  x: number;
  y: number;
}

export interface Bubble {
  id: string;
  row: number;
  col: number;
  color: BubbleColor;
  x: number;
  y: number;
  // Visual animation properties
  scale: number;
  alpha: number;
  connected?: boolean;
}

export interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: BubbleColor;
  active: boolean;
  powerUp?: PowerUpType;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
  shape?: 'circle' | 'spark' | 'ring';
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  size: number;
  alpha: number;
  vy: number;
  life: number;
}

export interface DetachedBubble {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: BubbleColor;
  rotation: number;
  vRot: number;
  alpha: number;
  bounced: number;
}

export interface ScoreBucket {
  index: number;
  x: number;
  width: number;
  points: number;
  label: string;
  hitAnim: number; // 0 to 1
}

export interface LevelConfig {
  id: number;
  name: string;
  themeName: string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Expert';
  bubbleLimit: number;
  starThresholds: [number, number, number];
  allowedColors: StandardColor[];
  initialGrid: (BubbleColor | null)[][];
  foulsBeforeCeilingDrop: number;
  description: string;
}

export type GameStatus =
  | 'idle'
  | 'aiming'
  | 'firing'
  | 'processing'
  | 'won'
  | 'lost'
  | 'paused';

export interface GameStats {
  score: number;
  movesRemaining: number;
  bubblesPopped: number;
  detachedCount: number;
  combos: number;
  maxCombo: number;
  starsEarned: number;
}

export interface UserProgress {
  unlockedLevel: number;
  levelStars: Record<number, number>;
  levelHighScores: Record<number, number>;
  powerUpInventory: Record<PowerUpType, number>;
  soundEnabled: boolean;
  aimGuideEnabled: boolean;
}
