/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BubbleColor, BubbleVisualConfig } from './types';

export const CANVAS_WIDTH = 460;
export const CANVAS_HEIGHT = 680;

export const BUBBLE_RADIUS = 19;
export const BUBBLE_DIAMETER = BUBBLE_RADIUS * 2;
export const ROW_HEIGHT = BUBBLE_RADIUS * Math.sqrt(3); // ~32.9px

export const COLS_EVEN = 12; // 12 * 38 = 456 -> fits with 2px margins
export const COLS_ODD = 11;
export const MAX_GRID_ROWS = 15;

export const CEILING_START_Y = 24;
export const LAUNCHER_X = CANVAS_WIDTH / 2;
export const LAUNCHER_Y = CANVAS_HEIGHT - 65;
export const NEXT_BUBBLE_X = LAUNCHER_X - 68;
export const NEXT_BUBBLE_Y = LAUNCHER_Y + 12;

export const PROJECTILE_SPEED = 24; // smooth & snappy
export const DANGER_LINE_ROW = 11;

export const BUBBLE_STYLES: Record<BubbleColor, BubbleVisualConfig> = {
  red: {
    primary: '#ef4444',
    secondary: '#b91c1c',
    highlight: '#fca5a5',
    glow: 'rgba(239, 68, 68, 0.45)',
  },
  blue: {
    primary: '#38bdf8',
    secondary: '#0284c7',
    highlight: '#bae6fd',
    glow: 'rgba(56, 189, 248, 0.45)',
  },
  green: {
    primary: '#10b981',
    secondary: '#047857',
    highlight: '#a7f3d0',
    glow: 'rgba(16, 185, 129, 0.45)',
  },
  yellow: {
    primary: '#fbbf24',
    secondary: '#d97706',
    highlight: '#fef08a',
    glow: 'rgba(251, 191, 36, 0.45)',
  },
  purple: {
    primary: '#a855f7',
    secondary: '#7e22ce',
    highlight: '#e9d5ff',
    glow: 'rgba(168, 85, 247, 0.45)',
  },
  cyan: {
    primary: '#06b6d4',
    secondary: '#0e7490',
    highlight: '#a5f3fc',
    glow: 'rgba(6, 182, 212, 0.45)',
  },
  bomb: {
    primary: '#374151',
    secondary: '#111827',
    highlight: '#f87171',
    glow: 'rgba(239, 68, 68, 0.7)',
    icon: '💣',
  },
  fireball: {
    primary: '#f97316',
    secondary: '#c2410c',
    highlight: '#fed7aa',
    glow: 'rgba(249, 115, 22, 0.7)',
    icon: '🔥',
  },
  rainbow: {
    primary: '#ec4899',
    secondary: '#8b5cf6',
    highlight: '#ffffff',
    glow: 'rgba(236, 72, 153, 0.75)',
    icon: '🌈',
  },
  lightning: {
    primary: '#eab308',
    secondary: '#ca8a04',
    highlight: '#fef9c3',
    glow: 'rgba(234, 179, 8, 0.7)',
    icon: '⚡',
  },
  stone: {
    primary: '#64748b',
    secondary: '#334155',
    highlight: '#cbd5e1',
    glow: 'rgba(100, 116, 139, 0.3)',
    icon: '🧱',
  },
};

export const DEFAULT_BUCKETS = [
  { index: 0, x: 0, width: CANVAS_WIDTH / 5, points: 100, label: '100', hitAnim: 0 },
  { index: 1, x: CANVAS_WIDTH / 5, width: CANVAS_WIDTH / 5, points: 250, label: '250', hitAnim: 0 },
  { index: 2, x: (CANVAS_WIDTH / 5) * 2, width: CANVAS_WIDTH / 5, points: 500, label: '500', hitAnim: 0 },
  { index: 3, x: (CANVAS_WIDTH / 5) * 3, width: CANVAS_WIDTH / 5, points: 250, label: '250', hitAnim: 0 },
  { index: 4, x: (CANVAS_WIDTH / 5) * 4, width: CANVAS_WIDTH / 5, points: 100, label: '100', hitAnim: 0 },
];
