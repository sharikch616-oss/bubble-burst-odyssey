# Bubble Burst Odyssey — Android-ready project

This is a WebView Android wrapper for the supplied Vite/React game.

## Important
The original ZIP is a Vite + React + TypeScript project. It must first be compiled with `npm run build` to create `dist/`. This environment could not download npm packages, so the compiled `dist/` is not included yet.

## Build on Android phone
1. Install an Android IDE such as Android IDE - PHONE AS / AndroidIDE.
2. Extract this ZIP.
3. In `web-source/`, run:
   `npm install`
   then `npm run build`
4. Copy everything from `web-source/dist/` into:
   `app/src/main/assets/www/`
5. Open the root folder in the Android IDE and build the APK.

The APK package is `com.bubbleburst.odyssey` and the app name is `Bubble Burst Odyssey`.
