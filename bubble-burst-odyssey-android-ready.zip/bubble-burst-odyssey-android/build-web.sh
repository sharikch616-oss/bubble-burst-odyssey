#!/system/bin/sh
set -e
cd "$(dirname "$0")/web-source"
npm install
npm run build
rm -rf ../app/src/main/assets/www/*
cp -R dist/. ../app/src/main/assets/www/
echo 'Web build copied into Android assets.'
